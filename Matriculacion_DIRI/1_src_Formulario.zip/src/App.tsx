import './App.css'
import EnrolmentForm from './components/EnrolmentForm/EnrolmentForm'
function App() {
  return (
    <>
      <EnrolmentForm></EnrolmentForm>
    </>
  )
}
export default App