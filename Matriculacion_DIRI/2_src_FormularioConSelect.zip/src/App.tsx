import { ChangeEvent, useState } from 'react';
import './App.css'
import EnrolmentForm from './components/EnrolmentForm/EnrolmentForm'



function App() {
  //Se genera estado del programa selaccionado, por default será siempre Grado
  const [program, setProgram] = useState("UG");

  //Se genera el estado para enrolments que contendrá el número matriculas en cada programa
  const [enrolments, setEnrolments] = useState(0);

  //Se crea el manejador del programa
  const handleChangeProgram = (event: ChangeEvent<HTMLSelectElement>) => {
    setProgram(event.target.value);
  };

  //Manejador para actualizar el estado de enrolments
  const handleChangeEnrolments = (updateEnrolments: number) => {
    setEnrolments(updateEnrolments);
  };

  return (
    <div className="App">
      <div className="programs">
        <label>Selecciona el tipo de estudio:</label>
        {
          //Se genera un select para sleccionar el programa
        }
        <select
          className="appDropDowns"
          onChange={handleChangeProgram}
          value={program}>
          <option value="UG">Grado</option>
          <option value="PG">Postgrado</option>
        </select>
        <div>Matriculaciones actuales: {enrolments}</div>
      </div>
      {
        //Agregamos el componente de formulario
      }
      <EnrolmentForm
        chosenProgram={program}
        onChangeEnrolments={handleChangeEnrolments}
        currentEnrolments={enrolments} />
    </div>
  )
}

export default App