import React, { FormEvent, useState } from 'react'
import './EnrolmentForm.css'

interface EnrolmentFormProps {
    //Para recibir el prop del programa seleccionado y pintarlo en el título
    chosenProgram: string;
    //Para recbir por prop la cantidad de veces que se presionó registrar
    currentEnrolments: number;
    //Para actualizar el valor enrolment
    onChangeEnrolments: (updateEnrolments: number) => void;
}

function EnrolmentForm(props: EnrolmentFormProps) {
    const [firstName, setFirstName] = useState("");
    const [lastName, setLastName] = useState("");
    const [welcomeMessage, setWelcomeMessage] = useState("");

    //Manejador del submit
    const handleSubmit = (event: FormEvent<HTMLFormElement>) => {
        //Modificamos el estado de mensaje con el nombre y el apellido del estudiante agregado
        setWelcomeMessage(`Bienvenido/a ${firstName} ${lastName}`);
        //Se apunta a la función para indicar que el enrolments a cambiado(le sumamos 1)
        props.onChangeEnrolments(props.currentEnrolments + 1);
        //Evitamos que se recargue la página
        event.preventDefault();
    };
    return (
        <div>
            <form className="enrolForm" onSubmit={handleSubmit}>
                <h1>Datos del estudiante - {props.chosenProgram}</h1>
                <label>Nombre:</label>
                <input type="text" name="fname"
                    onBlur={(event) => setFirstName(event.target.value)}
                />
                <label>Apellidos:</label>
                <input type="text" name="lname"
                    onBlur={(event) => setLastName(event.target.value)}
                />
                <input type="submit" value="Registrar" />
                <label id="studentMsg"
                    className="message">{welcomeMessage}</label>
            </form>
        </div>
    );
}
export default EnrolmentForm