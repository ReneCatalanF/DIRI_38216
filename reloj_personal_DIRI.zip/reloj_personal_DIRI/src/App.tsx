import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import Reloj_Personal from './reloj'

function App() {

  return (
    <div>
      <h1>RELOJ PERSONAL</h1>
      <div>
        <Reloj_Personal/>
      </div>
    </div>
  )
}

export default App
